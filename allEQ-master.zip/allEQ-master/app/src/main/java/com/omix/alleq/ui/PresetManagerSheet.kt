package com.omix.alleq.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omix.alleq.model.EqualizerPreset
import com.omix.alleq.ui.haptics.AppHaptics
import com.omix.alleq.ui.theme.BenzinFontFamily
import com.omix.alleq.ui.theme.LocalEqColors
import com.omix.alleq.ui.theme.WixFontFamily
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresetManagerSheet(
    onDismiss: () -> Unit,
    allPresets: List<EqualizerPreset>,
    deletedPresets: List<EqualizerPreset>,
    activePresetName: String,
    onReorder: (List<EqualizerPreset>) -> Unit,
    onDelete: (String) -> Unit,
    onRestore: (String) -> Unit,
    onResetToDefaults: () -> Unit,
    onSharePreset: (EqualizerPreset) -> Unit = {},
    onExportAllPresets: () -> Unit = {},
    onImportPresetsFile: () -> Unit = {}
) {
    val colors = LocalEqColors.current
    val context = LocalContext.current
    val view = LocalView.current

    // local queue drives the drag, service gets the final order on drop only
    var queue by remember { mutableStateOf(allPresets) }
    var isDragging by remember { mutableStateOf(false) }
    LaunchedEffect(allPresets) { if (!isDragging) queue = allPresets }

    val listState = rememberLazyListState()
    val reorderState = rememberReorderableLazyListState(listState) { from, to ->
        val fromIndex = queue.indexOfFirst { it.name == from.key }
        val toIndex = queue.indexOfFirst { it.name == to.key }
        if (fromIndex >= 0 && toIndex >= 0) {
            queue = queue.toMutableList().apply { add(toIndex, removeAt(fromIndex)) }
            AppHaptics.tick(view, context)
        }
    }

    fun commitQueue() {
        isDragging = false
        if (queue.map { it.name } != allPresets.map { it.name }) onReorder(queue)
    }

    var statusBarCover by remember { mutableFloatStateOf(0f) }
    val cornerRadius = 28.dp * (1f - statusBarCover)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = colors.sheetBg,
        dragHandle = { SheetDragHandle(onStatusBarCover = { statusBarCover = it }) },
        shape = RoundedCornerShape(topStart = cornerRadius, topEnd = cornerRadius)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Column {
                    Text(
                        text = "PRESET QUEUE & MANAGER",
                        fontFamily = BenzinFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        letterSpacing = 0.5.sp,
                        color = colors.textPrimary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_manager_drag_hint),
                        fontFamily = WixFontFamily,
                        fontSize = 12.sp,
                        color = colors.textSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE QUEUE",
                            fontFamily = BenzinFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp,
                            color = colors.textSecondary
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (colors.isDark) Color(0xFF222222) else Color(0xFFE8ECEF))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${queue.size}",
                                fontFamily = WixFontFamily,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = colors.textPrimary
                            )
                        }
                    }
                }

                itemsIndexed(queue, key = { _, item -> item.name }) { index, preset ->
                    val isActive = activePresetName.equals(preset.name, ignoreCase = true)

                    ReorderableItem(reorderState, key = preset.name) { isBeingDragged ->
                    val lift by animateFloatAsState(if (isBeingDragged) 1f else 0f, label = "lift")
                    val elevation by animateDpAsState(if (isBeingDragged) 10.dp else 0.dp, label = "elevation")
                    val borderColor by animateColorAsState(
                        when {
                            isBeingDragged -> colors.textPrimary.copy(alpha = 0.6f)
                            isActive -> colors.accent
                            else -> colors.borderSubtle
                        },
                        label = "border",
                    )

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isBeingDragged) colors.surfaceElevated else colors.sheetCardBg
                        ),
                        border = BorderStroke(if (isActive && !isBeingDragged) 1.2.dp else 1.dp, borderColor),
                        elevation = CardDefaults.cardElevation(elevation),
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                val scale = 1f + 0.03f * lift
                                scaleX = scale
                                scaleY = scale
                            }
                            // long press anywhere on the card, like a player queue
                            .longPressDraggableHandle(
                                onDragStarted = {
                                    isDragging = true
                                    AppHaptics.heavyClick(view, context)
                                },
                                onDragStopped = { commitQueue() },
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                 .fillMaxWidth()
                                 .padding(horizontal = 14.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "${index + 1}.",
                                        fontFamily = WixFontFamily,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textMuted
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = preset.name.uppercase(),
                                        fontFamily = BenzinFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 0.3.sp,
                                        color = colors.textPrimary
                                    )
                                    if (isActive) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(colors.accent.copy(alpha = 0.15f))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_active),
                                                fontFamily = WixFontFamily,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = colors.accent
                                            )
                                        }
                                    }
                                    if (preset.isCustom) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (colors.isDark) Color(0xFF2A2A38) else Color(0xFFEDE7F6))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_custom),
                                                fontFamily = WixFontFamily,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF7C4DFF)
                                            )
                                        }
                                    }
                                }

                                val localizedDesc = getLocalizedPresetDescription(preset)
                                if (localizedDesc.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = localizedDesc.lowercase(),
                                        fontFamily = WixFontFamily,
                                        fontSize = 11.sp,
                                        color = colors.textSecondary,
                                        maxLines = 1
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onSharePreset(preset) },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = colors.textSecondary,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { onDelete(preset.name) },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFFF5252),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .draggableHandle(
                                            onDragStarted = {
                                                isDragging = true
                                                AppHaptics.heavyClick(view, context)
                                            },
                                            onDragStopped = { commitQueue() },
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DragHandle,
                                        contentDescription = "Drag to reorder",
                                        tint = if (isBeingDragged) colors.textPrimary else colors.textMuted,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                    }
                }

                if (deletedPresets.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "DELETED PRESETS",
                                fontFamily = BenzinFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp,
                                color = Color(0xFFFF8A80)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (colors.isDark) Color(0xFF331818) else Color(0xFFFFEBEE))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${deletedPresets.size}",
                                    fontFamily = WixFontFamily,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFF5252)
                                )
                            }
                        }
                    }

                    itemsIndexed(deletedPresets, key = { _, item -> "del_" + item.name }) { _, preset ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (colors.isDark) Color(0xFF151212) else Color(0xFFFFF7F7)
                            ),
                            border = BorderStroke(1.dp, if (colors.isDark) Color(0xFF261818) else Color(0xFFFFE0E0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = preset.name.uppercase(),
                                        fontFamily = BenzinFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = colors.textSecondary
                                    )
                                    val localizedDesc = getLocalizedPresetDescription(preset)
                                    if (localizedDesc.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = localizedDesc.lowercase(),
                                            fontFamily = WixFontFamily,
                                            fontSize = 11.sp,
                                            color = colors.textMuted,
                                            maxLines = 1
                                        )
                                    }
                                }

                                Button(
                                    onClick = { onRestore(preset.name) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (colors.isDark) Color(0xFF242020) else Color(0xFFE8F5E9),
                                        contentColor = Color(0xFF4CAF50)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Restore,
                                        contentDescription = "Restore",
                                        modifier = Modifier.size(15.dp),
                                        tint = Color(0xFF4CAF50)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.btn_restore),
                                        fontFamily = WixFontFamily,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF4CAF50)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onImportPresetsFile,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, colors.border),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.accent),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileOpen,
                                contentDescription = "Import",
                                modifier = Modifier.size(16.dp),
                                tint = colors.accent
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.btn_import_preset_file),
                                fontFamily = WixFontFamily,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }

                        OutlinedButton(
                            onClick = onExportAllPresets,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, colors.border),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.textPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Export All",
                                modifier = Modifier.size(16.dp),
                                tint = colors.textPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.btn_export_all_presets),
                                fontFamily = WixFontFamily,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onResetToDefaults,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, colors.border),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.textSecondary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset",
                            modifier = Modifier.size(16.dp),
                            tint = colors.textSecondary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.btn_reset_defaults),
                            fontFamily = WixFontFamily,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun getLocalizedPresetDescription(preset: EqualizerPreset): String {
    if (preset.isCustom) return preset.description
    return when (preset.name.lowercase()) {
        "flat" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_flat)
        "bass punch" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_bass_punch)
        "vocal clarity" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_vocal_clarity)
        "club" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_club)
        "rock" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_rock)
        "cinematic" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_cinematic)
        "acoustic" -> androidx.compose.ui.res.stringResource(com.omix.alleq.R.string.preset_desc_acoustic)
        else -> preset.description
    }
}
